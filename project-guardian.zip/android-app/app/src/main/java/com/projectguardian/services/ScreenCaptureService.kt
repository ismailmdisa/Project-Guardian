package com.projectguardian.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * DEEP VISION AGENT (Screen Capture Service)
 * 1. Uses MediaProjection to capture the screen continuously.
 * 2. Feeds the frames to the TensorFlow Lite model (YOLO26 INT8).
 */
class ScreenCaptureService : Service() {

    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var modestyAnalyzer: com.projectguardian.ai.ModestyAnalyzer? = null
    
    private val handlerThread = HandlerThread("ScreenCaptureThread")
    private lateinit var backgroundHandler: Handler

    override fun onCreate() {
        super.onCreate()
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        handlerThread.start()
        backgroundHandler = Handler(handlerThread.looper)
        modestyAnalyzer = com.projectguardian.ai.ModestyAnalyzer(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>("RESULT_DATA")

        if (resultCode != -1 && resultData != null) {
            startForegroundService()
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
            startScreenCapture()
        }

        return START_STICKY
    }

    private fun startForegroundService() {
        val channelId = "GuardianScreenCapture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Screen Monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Project Guardian Active")
            .setContentText("Monitoring screen for explicit content...")
            .setSmallIcon(android.R.drawable.ic_secure)
            .build()

        startForeground(1, notification)
    }

    private fun startScreenCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        // Highly optimized format for TensorFlow Lite (ARGB_8888)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "GuardianScreenCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, backgroundHandler
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image: Image? = reader.acquireLatestImage()
            if (image != null) {
                try {
                    val bitmap = imageToBitmap(image)
                    val detections = modestyAnalyzer?.analyzeFrame(bitmap) ?: emptyList()
                    
                    val accessibilityService = GuardianAccessibilityService.getInstance()
                    if (detections.isNotEmpty()) {
                        accessibilityService?.drawObfuscationOverlay(detections)
                    } else {
                        accessibilityService?.removeObfuscationOverlay()
                    }
                } catch (e: Exception) {
                    android.util.Log.e("ScreenCapture", "Error analyzing frame", e)
                } finally {
                    image.close()
                }
            }
        }, backgroundHandler)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width
        
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        mediaProjection?.stop()
        imageReader?.close()
        modestyAnalyzer?.close()
        handlerThread.quitSafely()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
