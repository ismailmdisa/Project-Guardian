package com.projectguardian.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import com.projectguardian.R

/**
 * UI Lockdown Agent & Unyielding Sentinel
 * 1. Draws the blur/black overlay over inappropriate content.
 * 2. Blocks uninstallation by monitoring the Settings and Package Installer apps.
 */
class GuardianAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: GuardianAccessibilityService? = null

        fun getInstance(): GuardianAccessibilityService? = instance
    }

    private lateinit var windowManager: WindowManager
    private val overlayViews = mutableListOf<View>()
    private var isAuthDialogShowing = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_VIEW_SCROLLED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            packageNames = null // Monitor all apps
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // UNYIELDING SENTINEL: Anti-Uninstall Protection
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            val className = event.className?.toString() ?: return

            // Block Android Settings (Device Admin removal) and Package Installer (Uninstallation)
            if (packageName == "com.android.settings" || packageName == "com.google.android.packageinstaller") {
                // Check if the user is trying to access Device Admin or App Info screens
                if (className.contains("DeviceAdmin") || className.contains("InstalledAppDetails")) {
                    showAuthDialog() // Trigger custom confirmation dialog
                    // TODO: Trigger Accountability Partner Alert here
                }
            }
        }
    }

    /**
     * UI LOCKDOWN AGENT: Draws dynamic obfuscation overlays
     * Called by the Deep Vision Agent (TensorFlow Lite) when explicit content is detected.
     */
    fun drawObfuscationOverlay(boxes: List<com.projectguardian.ai.BoundingBox>) {
        // Run on main thread because we're touching UI
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            if (boxes.isEmpty()) {
                removeAllOverlays()
                return@post
            }

            // Sync overlay views with boxes
            while (overlayViews.size < boxes.size) {
                val newView = FrameLayout(this).apply {
                    setBackgroundColor(android.graphics.Color.BLACK) // Or Gaussian Blur
                }
                val params = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                }
                windowManager.addView(newView, params)
                overlayViews.add(newView)
            }

            while (overlayViews.size > boxes.size) {
                val viewToRemove = overlayViews.removeAt(overlayViews.size - 1)
                windowManager.removeView(viewToRemove)
            }

            // Update positions and sizes
            for (i in boxes.indices) {
                val box = boxes[i]
                val view = overlayViews[i]
                val params = view.layoutParams as WindowManager.LayoutParams
                params.x = box.x
                params.y = box.y
                params.width = box.width
                params.height = box.height
                windowManager.updateViewLayout(view, params)
            }
        }
    }

    fun removeObfuscationOverlay() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            removeAllOverlays()
        }
    }

    private fun removeAllOverlays() {
        overlayViews.forEach { windowManager.removeView(it) }
        overlayViews.clear()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllOverlays()
        instance = null
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    private fun showAuthDialog() {
        if (isAuthDialogShowing) return
        isAuthDialogShowing = true

        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val context = this
            val container = android.widget.FrameLayout(context).apply {
                setBackgroundColor(android.graphics.Color.parseColor("#B3000000")) // 70% black
            }

            val card = android.widget.LinearLayout(context).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setBackgroundColor(android.graphics.Color.WHITE)
                setPadding(64, 64, 64, 64)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.WHITE)
                    cornerRadius = 24f
                }
            }

            val title = android.widget.TextView(context).apply {
                text = "Action Blocked"
                textSize = 22f
                setTextColor(android.graphics.Color.BLACK)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            card.addView(title)

            val message = android.widget.TextView(context).apply {
                text = "Please enter your Guardian PIN to proceed with this action."
                setTextColor(android.graphics.Color.DKGRAY)
                setPadding(0, 32, 0, 32)
                textSize = 16f
            }
            card.addView(message)

            val input = android.widget.EditText(context).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
                setTextColor(android.graphics.Color.BLACK)
                hint = "Enter PIN"
                setPadding(32, 32, 32, 32)
            }
            card.addView(input)

            val buttonLayout = android.widget.LinearLayout(context).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.END
                setPadding(0, 48, 0, 0)
            }

            val cancelBtn = android.widget.Button(context).apply {
                text = "Cancel"
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setTextColor(android.graphics.Color.DKGRAY)
            }
            buttonLayout.addView(cancelBtn)

            val submitBtn = android.widget.Button(context).apply {
                text = "Unlock"
                setBackgroundColor(android.graphics.Color.parseColor("#059669")) // Emerald 600
                setTextColor(android.graphics.Color.WHITE)
            }
            buttonLayout.addView(submitBtn)

            card.addView(buttonLayout)
            
            val cardParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = android.view.Gravity.CENTER
                setMargins(64, 64, 64, 64)
            }
            container.addView(card, cardParams)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT
            ).apply {
                dimAmount = 0.7f
            }

            var isRemoved = false
            val removeDialog = {
                if (!isRemoved) {
                    windowManager.removeView(container)
                    isRemoved = true
                    isAuthDialogShowing = false
                }
            }

            cancelBtn.setOnClickListener {
                removeDialog()
                performGlobalAction(GLOBAL_ACTION_HOME)
            }

            submitBtn.setOnClickListener {
                val pin = input.text.toString()
                if (pin == "1234") { // Hardcoded for demonstration
                    removeDialog()
                    // Allow action
                } else {
                    android.widget.Toast.makeText(context, "Incorrect PIN", android.widget.Toast.LENGTH_SHORT).show()
                    removeDialog()
                    performGlobalAction(GLOBAL_ACTION_HOME)
                }
            }

            container.isFocusableInTouchMode = true
            container.requestFocus()
            container.setOnKeyListener { _, keyCode, event ->
                if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                    removeDialog()
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    true
                } else {
                    false
                }
            }

            windowManager.addView(container, params)
        }
    }
}
